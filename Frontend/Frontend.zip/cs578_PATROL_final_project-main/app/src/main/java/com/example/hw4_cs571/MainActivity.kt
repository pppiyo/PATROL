package com.example.hw4_cs571

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.splashscreen.SplashScreen
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.viewpager2.widget.ViewPager2
import com.example.hw4_cs571.Model.CheckIn
import com.example.hw4_cs571.Model.Coordinate
import com.example.hw4_cs571.ViewModel.MainActivityViewModel
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.tasks.CancellationToken
import com.google.android.gms.tasks.CancellationTokenSource
import com.google.android.gms.tasks.OnTokenCanceledListener
import com.google.android.material.tabs.TabLayout
import java.time.LocalDateTime


class MainActivity : AppCompatActivity() {


    lateinit var tlMainActivity: TabLayout
    lateinit var vpMainActivity: ViewPager2
    lateinit var mainActivViewPager2Adapter: MainActivViewPagerAdapter

    private var splashDelay: Boolean = true

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private val mainActivityViewModel: MainActivityViewModel by viewModels<MainActivityViewModel>()

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        //Check location permission and checkin user location
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)

        checkLocationPermission()

        splashScreen.setKeepOnScreenCondition {
            splashDelay
        }

    }

    private fun initialScreen() {
        setContentView(R.layout.activity_main)

        tlMainActivity = findViewById(R.id.tlDeatilsOptions)
        vpMainActivity = findViewById(R.id.vp2Details)
        vpMainActivity.isUserInputEnabled = false
        mainActivViewPager2Adapter = MainActivViewPagerAdapter(this)
        vpMainActivity.adapter = mainActivViewPager2Adapter

        // Now let's set the addOnTabSelectedListener for the TabLayout object.
        // This is to go to the corresponding ViewPager page when a tab is selected.
        tlMainActivity.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                // We will use the when statement to check which tab was selected.
                when (tab?.position) {
                    0 -> vpMainActivity.currentItem = 0
                    1 -> vpMainActivity.currentItem = 1
                    2 -> vpMainActivity.currentItem = 2
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                // We don't need to do anything here.
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {
                // We don't need to do anything here.
            }

        })

        // This highlights the tab when the corresponding ViewPager page is selected.
        vpMainActivity.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                // We will use the when statement to check which tab was selected.
                when (position) {
                    0 -> tlMainActivity.selectTab(tlMainActivity.getTabAt(0))
                    1 -> tlMainActivity.selectTab(tlMainActivity.getTabAt(1))
                    2 -> tlMainActivity.selectTab(tlMainActivity.getTabAt(2))
                }
            }
        })

        splashDelay = false
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun checkLocationPermission() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                1
            )
        } else {
            getCurrentLocation()
            initialScreen()
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        // Check location permission and execute get location
        when {
            grantResults[0] >= 0 -> {
                getCurrentLocation()
                initialScreen()
            }

            grantResults[1] >= 0 -> {
                getCurrentLocation()
                initialScreen()
            }

            else -> {
                initialScreen()
                // No location access granted.
            }
        }
    }


    @SuppressLint("MissingPermission")
    @RequiresApi(Build.VERSION_CODES.O)
    private fun getCurrentLocation() {
        fusedLocationClient.getCurrentLocation(
            Priority.PRIORITY_HIGH_ACCURACY,
            object : CancellationToken() {
                override fun onCanceledRequested(p0: OnTokenCanceledListener) =
                    CancellationTokenSource().token

                override fun isCancellationRequested() = false
            })
            .addOnSuccessListener { location: Location? ->
                if (location == null)
                    Toast.makeText(this, "Cannot get location.", Toast.LENGTH_SHORT).show()
                else {
                    updateUserLocation(LatLng(location.latitude, location.longitude))
                }

            }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun updateUserLocation(currentLocation: LatLng) {
        val sharedPreference = getSharedPreferences("USER", Context.MODE_PRIVATE)
        if (sharedPreference.getBoolean("first_time", true)) {
            var editor = sharedPreference.edit()
            editor.putBoolean("first_time", false)
            editor.commit()
            var firstInstall = CheckIn(
                userId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID),
                lat = currentLocation.latitude,
                lng = currentLocation.longitude,
                createAt = LocalDateTime.now()
            )
            mainActivityViewModel.setFirstTimeInstall(firstInstall)
        } else {
            mainActivityViewModel.updateUserLocation(
                Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID),
                Coordinate(currentLocation.latitude, currentLocation.longitude)
            )
        }
    }
}