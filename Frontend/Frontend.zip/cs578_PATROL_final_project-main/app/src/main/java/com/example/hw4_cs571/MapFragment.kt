package com.example.hw4_cs571

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RawRes
import androidx.fragment.app.Fragment
import com.example.hw4_cs571.ViewModel.MapViewModel
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.TileOverlayOptions
import com.google.maps.android.ktx.utils.heatmaps.heatmapTileProviderWithData
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.lifecycle.coroutineScope
import com.example.hw4_cs571.Model.Coordinate
import com.example.hw4_cs571.Model.State
import com.example.hw4_cs571.ViewModel.MainActivityViewModel
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.maps.android.ktx.awaitMap
import com.google.maps.android.ktx.awaitMapLoad
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONException
import java.util.Scanner

class MapFragment : Fragment() {

    private lateinit var fragmentView: View
    private lateinit var stateList: List<State>
    private lateinit var mapFragment: SupportMapFragment
    private lateinit var spLocation: Spinner
    private lateinit var tvSubmit: TextView
    private lateinit var etRadius: EditText
    private lateinit var fab: View
    private val mapViewModel: MapViewModel by viewModels<MapViewModel>()


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        fragmentView = inflater.inflate(R.layout.fragment_map, container, false)
        stateList = readItems(R.raw.coordinates)
        return fragmentView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialSearchBar(view)
        mapViewModel.getHeatMapData()

        mapFragment = childFragmentManager.findFragmentById(R.id.id_map) as SupportMapFragment

        mapViewModel.searchData.observe(viewLifecycleOwner, Observer { searchData ->
            val selectState = stateList.first() { state -> state.state == searchData.searchLocation }

            lifecycle.coroutineScope.launch {
                val googleMap = mapFragment.awaitMap()
                googleMap.awaitMapLoad()
                googleMap.animateCamera(
                    CameraUpdateFactory.newLatLngZoom(
                        LatLng(selectState.coordinate.lat,selectState.coordinate.lng),
                        searchData.radius
                    )
                )

                addHeatMap(googleMap)
            }
        })

        fab = view.findViewById(R.id.fab)
        fab.setOnClickListener { view ->
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://covid.cdc.gov/covid-data-tracker/#maps_new-admissions-rate-county"))
            startActivity(i)
        }

    }

    private fun initialSearchBar(view:View){
        spLocation = view.findViewById(R.id.spLocation)

        // We will create an ArrayAdapter object to populate the Spinner object.
        val locationArray = resources.getStringArray(R.array.US_states)
        val locationAdapter = ArrayAdapter(view.context, R.layout.color_spinner_layout, locationArray)

        // Add onclick listener to submit button
        spLocation.adapter = locationAdapter
        tvSubmit = view.findViewById(R.id.tvSubmit)
        etRadius = view.findViewById(R.id.etRadius)
        tvSubmit.setOnClickListener {
            mapViewModel.updateArea(
                spLocation.selectedItem.toString(),
                etRadius.text.toString().toFloat()
            )
        }
    }

    private suspend fun addHeatMap(googleMap: GoogleMap) {
        googleMap.awaitMapLoad()

        mapViewModel.heatMapData.observe(viewLifecycleOwner) {
            googleMap.addTileOverlay(
                TileOverlayOptions()
                    .tileProvider(
                        heatmapTileProviderWithData(it, 50)
                    )
            )
        }


    }

    @Throws(JSONException::class)
    private fun readItems(@RawRes resource: Int): List<State> {
        val result: MutableList<State> = ArrayList()
        val inputStream = this.resources.openRawResource(resource)
        val json = Scanner(inputStream).useDelimiter("\\A").next()
        val array = JSONArray(json)
        for (i in 0 until array.length()) {
            val `object` = array.getJSONObject(i)
            val stateName = `object`.getString("state")
            val coordinate = `object`.getJSONObject("coordinate")
            val lat = coordinate.getDouble("lat")
            val lng = coordinate.getDouble("lng")
            result.add(State(stateName, Coordinate(lat, lng)))
        }
        return result
    }
}