package com.example.hw4_cs571

import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.hw4_cs571.Model.PostData
import com.example.hw4_cs571.ViewModel.PostViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

class PostFragment : Fragment() {

    lateinit var fragmentView: View
    lateinit var btnPostNotif : TextView
    lateinit var progBar: ProgressBar
    lateinit var tvPosting: TextView
    lateinit var tvThankYou: TextView

    val postViewModel = PostViewModel()
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        fragmentView = inflater.inflate(R.layout.fragment_post, container, false)
        btnPostNotif = fragmentView.findViewById(R.id.btnPostNotif)

        btnPostNotif.setOnClickListener {

            progBar = fragmentView.findViewById(R.id.progBar)
            tvPosting = fragmentView.findViewById(R.id.tvPosting)
            tvThankYou = fragmentView.findViewById(R.id.tvThankYou)

            tvThankYou.isVisible = false
            progBar.isVisible = true
            tvPosting.isVisible = true

            lifecycleScope.launch {
                // let's get the current time-zone in the format of "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"

                val desiredZoneId = ZoneId.of("UTC")
                val currentZoneDateTime = ZonedDateTime.now(desiredZoneId)

                val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")
                val formattedDateTime = currentZoneDateTime.format(formatter)

                val spEvent = fragmentView.findViewById<Spinner>(R.id.spEvent)
                val event = spEvent.selectedItem.toString()

                val etetOtherNotes = fragmentView.findViewById<EditText>(R.id.etOtherNotes)
                val textOfOtherNotes = etetOtherNotes.text.toString()


                val finalPostString = "Event type: $event\n" +
                                      "Other notes: $textOfOtherNotes"


                val post = PostData(formattedDateTime, finalPostString)

                postViewModel.postPost(post)

                delay(3000)
                progBar.isVisible = false
                tvPosting.isVisible = false
                tvThankYou.isVisible = true
            }
        }
        return fragmentView
    }

}