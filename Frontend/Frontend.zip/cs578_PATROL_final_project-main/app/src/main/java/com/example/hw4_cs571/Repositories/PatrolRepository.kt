package com.example.hw4_cs571.Repositories

import android.util.Log
import com.example.hw4_cs571.Data.RetrofitObject
import com.example.hw4_cs571.Model.CheckIn
import com.example.hw4_cs571.Model.CheckInData
import com.example.hw4_cs571.Model.Coordinate
import com.google.android.gms.maps.model.LatLng
import org.json.JSONException

class PatrolRepository{

    private val patrolApiService = RetrofitObject.patrolApiService

    suspend fun getHeatMapData(): List<LatLng> {
        var result: List<LatLng?> = ArrayList()
        result = extractLatLng(patrolApiService.getAllCheckIns())
        return result
    }

    suspend fun setFirstTimeInstall(checkIn: CheckIn){
        patrolApiService.checkIn(checkIn)
    }

    suspend fun updateUserLocation(userId: String, coordinate: Coordinate){
        patrolApiService.updateUserLocation(userId,coordinate)
    }

    @Throws(JSONException::class)
    private fun extractLatLng(checkInData: CheckInData): MutableList<LatLng> {
        val result: MutableList<LatLng> = ArrayList()
        for (i in checkInData.checkIns) {
            result.add(LatLng(i.lat, i.lng))
        }
        return result
    }

}