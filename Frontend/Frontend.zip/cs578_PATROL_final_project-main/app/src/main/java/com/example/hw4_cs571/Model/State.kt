package com.example.hw4_cs571.Model

data class State(
    val state: String,
    val coordinate: Coordinate,
)
