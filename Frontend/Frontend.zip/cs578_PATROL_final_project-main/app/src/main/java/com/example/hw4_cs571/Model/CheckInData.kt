package com.example.hw4_cs571.Model

data class CheckInData(
    val checkIns: List<CheckIn>
)