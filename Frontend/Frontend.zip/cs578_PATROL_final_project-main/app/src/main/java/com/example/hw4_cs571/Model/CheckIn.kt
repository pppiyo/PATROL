package com.example.hw4_cs571.Model

import java.time.LocalDateTime

data class CheckIn(
    val userId: String,
    val lat: Double,
    val lng: Double,
    val createAt: LocalDateTime
)
