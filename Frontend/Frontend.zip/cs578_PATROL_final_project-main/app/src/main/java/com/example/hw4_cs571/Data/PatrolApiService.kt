package com.example.hw4_cs571.Data

import com.example.hw4_cs571.Model.CheckIn
import com.example.hw4_cs571.Model.CheckInData
import com.example.hw4_cs571.Model.Coordinate
import com.example.hw4_cs571.Model.HistoryData
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive
import retrofit2.Response

import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

interface PatrolApiService {
    @GET("getAllCheckIns/")
    suspend fun getAllCheckIns(): CheckInData

    @GET("getHistory/{start_date}/{end_date}")
    suspend fun getHistory(@Path("start_date") startDate: String, @Path("end_date") endDate: String): HistoryData

    @POST("checkIn/")
    suspend fun checkIn(@Body checkIn: CheckIn)

    @PUT("checkIn/{user_id}")
    suspend fun updateUserLocation(@Path("user_id") userId: String,@Body coordinate: Coordinate)

    @GET("getPosts")
    suspend fun getPosts(): Response<JsonObject>

    @POST("post")
    suspend fun post(@Body postData: JsonObject): Response<JsonPrimitive>

}