package com.example.hw4_cs571

import android.app.DatePickerDialog
import android.graphics.Typeface
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.hw4_cs571.Model.HistoryData
import com.example.hw4_cs571.ViewModel.HistoryViewModel

import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.formatter.ValueFormatter
import java.text.ParseException

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale


class HistoryFragment : Fragment() {
    private lateinit var barChart: BarChart  // Declare barChart here
    private lateinit var viewModel: HistoryViewModel

    private var startDate: String? = null
    private var endDate: String? = null

    lateinit var fragmentView: View

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_history, container, false)
        barChart = view.findViewById(R.id.barChart) // Initialize using inflated view

        // Set default no data text for the chart
        barChart.setNoDataText("Please select start date and end date")
        barChart.setNoDataTextColor(
            ContextCompat.getColor(
                requireContext(),
                R.color.standard_purplee
            )
        )
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize viewModel first
        viewModel = ViewModelProvider(this).get(HistoryViewModel::class.java)

        viewModel.historyData.observe(viewLifecycleOwner) { historyData ->
            if (historyData != null) {
                updateChart(historyData)
            } else {
                Toast.makeText(context, "Failed to load data", Toast.LENGTH_SHORT).show()
            }
        }

        val btnStartDatePicker: Button = view.findViewById(R.id.btnStartDatePicker)
        val btnEndDatePicker: Button = view.findViewById(R.id.btnEndDatePicker)
        val btnSubmit: Button = view.findViewById(R.id.btnSubmit)

        val calendar = Calendar.getInstance()
        val datePickerListener = DatePickerDialog.OnDateSetListener { _, year, month, dayOfMonth ->
            val date =
                String.format(Locale.getDefault(), "%d-%02d-%02d", year, month + 1, dayOfMonth)

            // Show the selected date on the buttons
            if (currentPickerId == R.id.btnStartDatePicker) {
                startDate = date
                btnStartDatePicker.text = date
                Log.d("HistoryFragment", "Selected Start Date: $startDate")
            } else if (currentPickerId == R.id.btnEndDatePicker) {
                endDate = date
                btnEndDatePicker.text = date
                Log.d("HistoryFragment", "Selected End Date: $endDate")
            }
        }

        btnStartDatePicker.setOnClickListener {
            DatePickerDialog(
                requireContext(),
                datePickerListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
            currentPickerId = it.id
        }

        btnEndDatePicker.setOnClickListener {
            DatePickerDialog(
                requireContext(),
                datePickerListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
            currentPickerId = it.id
        }

        btnSubmit.setOnClickListener {
            if (startDate != null && endDate != null) {
                barChart.clear()
                barChart.setNoDataText("Loading...")
                barChart.invalidate()  // Update the chart to show loading message

                viewModel.fetchHistoryData(startDate!!, endDate!!)
            } else {
                Toast.makeText(
                    context,
                    "Please select both start and end dates.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

    }


    companion object {
        var currentPickerId: Int = 0
    }


    private fun updateChart(historyData: HistoryData) {
        val entries = ArrayList<BarEntry>()
        val labels = ArrayList<String>()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val labelFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

        historyData.history.forEachIndexed { index, item ->
            try {
                val date = dateFormat.parse(item.date)
                if (date != null) {
                    Log.d("Chart", "seeee: ${date}")
                    entries.add(BarEntry(index.toFloat(), item.total.toFloat()))
                    labels.add(labelFormat.format(date))
                } else {
                    Log.e("Chart", "Failed to parse date: ${item.date}")
                }
            } catch (e: ParseException) {
                Log.e("Chart", "ParseException for date: ${item.date}", e)
            }
        }

        if (entries.isEmpty()) {
            Log.d("Chart", "No entries to display.")
            val emptyDataSet = BarDataSet(listOf(BarEntry(0f, 0f)), "No Data")
            emptyDataSet.color = ContextCompat.getColor(
                requireContext(), R.color.standard_purplee
            )
            val emptyData = BarData(emptyDataSet)
            barChart.data = emptyData
            barChart.invalidate()
        } else {
            val dataSet = BarDataSet(entries, "Total Number")
            dataSet.color = ContextCompat.getColor(requireContext(), R.color.standard_purplee)
            val data = BarData(dataSet)
            barChart.data = data
        }

        barChart.xAxis.apply {
            valueFormatter = IndexAxisValueFormatter(labels)
            position = com.github.mikephil.charting.components.XAxis.XAxisPosition.BOTTOM
            setDrawGridLines(false)
            labelRotationAngle = -20f
            granularity = 1f
            yOffset = 15f
        }

        barChart.axisLeft.apply {
            axisMinimum = 0f // Ensures that our graph starts at zero
            granularity = 1f  // Increments by 1 to clearly show individual counts
            setDrawGridLines(true) // Enables grid lines for clarity
            textSize = 12f // Sets the size of the text for better visibility
            valueFormatter = object : ValueFormatter() { // Custom formatter for y-axis labels
                override fun getFormattedValue(value: Float): String {
                    return "${value.toInt()}" // Adds "people" to labels to clarify the count
                }
            }
        }

        barChart.axisRight.isEnabled = false // Disables the right axis as it's unnecessary

        barChart.description.apply {
            isEnabled = false // Hides the description label
        }

        barChart.legend.isEnabled = false // Disables the legend to simplify the chart

        barChart.extraBottomOffset =
            25f // Adds extra offset at the bottom to accommodate rotated labels

        barChart.setFitBars(true) // Ensures that bars fit within their designated space without overlapping
        barChart.invalidate() // Refreshes the chart to apply changes

    }
}