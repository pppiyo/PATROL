package com.example.hw4_cs571.Model

data class Coordinate(
    val lat: Double,
    val lng: Double
)
