package com.example.hw4_cs571.Model

data class SearchData(
    val searchLocation: String,
    val radius: Float,
)
