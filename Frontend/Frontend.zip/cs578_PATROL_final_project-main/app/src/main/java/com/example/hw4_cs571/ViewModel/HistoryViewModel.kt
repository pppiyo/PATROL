package com.example.hw4_cs571.ViewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.Dispatchers
import com.github.mikephil.charting.data.BarEntry
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale

import com.example.hw4_cs571.Repositories.PatrolRepository
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.hw4_cs571.Data.RetrofitObject
import kotlinx.coroutines.launch
import com.example.hw4_cs571.Model.HistoryData
import com.example.hw4_cs571.Model.HistoryItem


class HistoryViewModel : ViewModel() {
    private val patrolApiService = RetrofitObject.patrolApiService
        private val _historyData = MutableLiveData<HistoryData?>()
    val historyData: LiveData<HistoryData?> = _historyData

    fun fetchHistoryData(startDate: String, endDate: String) {
        viewModelScope.launch {
            try {
                val response = patrolApiService.getHistory(startDate, endDate)
                _historyData.postValue(response)
            } catch (e: Exception) {
                // Handle possible network errors
                _historyData.postValue(null)
            }
        }
    }
}
