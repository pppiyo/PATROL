package com.example.hw4_cs571.ViewModel

import com.example.hw4_cs571.Data.RetrofitObject
import com.example.hw4_cs571.Model.PostData
import com.google.gson.JsonObject
import org.json.JSONObject
import retrofit2.Response

class PostViewModel {

    private val patrolApiService = RetrofitObject.patrolApiService
    suspend fun postPost(postData: PostData) {

        val postAsJsonObj = JsonObject()
        postAsJsonObj.addProperty("createdAt", postData.createdAt)
        postAsJsonObj.addProperty("post", postData.post)

        patrolApiService.post(postAsJsonObj)
    }
}