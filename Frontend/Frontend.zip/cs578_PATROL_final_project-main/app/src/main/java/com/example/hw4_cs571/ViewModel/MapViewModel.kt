package com.example.hw4_cs571.ViewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.hw4_cs571.Model.CheckIn
import com.example.hw4_cs571.Model.SearchData
import com.example.hw4_cs571.Repositories.PatrolRepository
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.log2

class MapViewModel: ViewModel() {
    private val patrolRepository = PatrolRepository()
    private val _heatMapData = MutableLiveData<List<LatLng>>()
    private val _searchData = MutableLiveData<SearchData>(SearchData("Alabama", 12F))

    val heatMapData: LiveData<List<LatLng>>
        get() = _heatMapData

    val searchData: LiveData<SearchData>
        get() = _searchData

    fun getHeatMapData(){
        viewModelScope.launch {
            val result = patrolRepository.getHeatMapData()
            _heatMapData.postValue(result)
        }
    }

    fun updateArea(location: String, radius: Float) {
        _searchData.value = SearchData(location, calculateZoomLevel(radius))
    }

    private fun calculateZoomLevel(radius: Float): Float {
        var zoom = floor(log2(97.27130 * cos(37.0902 * Math.PI / 180) * 512 / radius)).toFloat()
        return zoom.toFloat()
    }


}