package com.example.hw4_cs571.Model

import com.google.gson.annotations.SerializedName

data class HistoryData(
    @SerializedName("history")
    val history: List<HistoryItem>
)

data class HistoryItem(
    @SerializedName("_id")
    val id: String,
    @SerializedName("date")
    val date: String,
    @SerializedName("total")
    val total: Int,
    @SerializedName("new")
    val new: Int
)
