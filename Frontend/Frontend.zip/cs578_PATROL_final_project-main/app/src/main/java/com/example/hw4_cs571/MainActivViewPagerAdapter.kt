package com.example.hw4_cs571

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
//import com.example.hw4_cs571.fragments.PhotosFragment

//import com.example.hw4_cs571.fragments.ShippingFragment
//import com.example.hw4_cs571.fragments.SimilarFragment

// Remember that with ": FragmentStateAdapter(fragment)" we are extending the
// FragmentStateAdapter class, and at the same time we are passing
// we are indicating that the constructor of our class will use the constructor
// of the FragmentStateAdapter class.
class MainActivViewPagerAdapter(fragmentActivity: FragmentActivity):
    FragmentStateAdapter(fragmentActivity) {



    override fun getItemCount(): Int {
        return 3
    }

    override fun createFragment(position: Int): Fragment {
        return when(position){
            0 -> MapFragment()
            1 -> HistoryFragment()
            2 -> PostFragment()
            else -> MapFragment()
        }
    }
}