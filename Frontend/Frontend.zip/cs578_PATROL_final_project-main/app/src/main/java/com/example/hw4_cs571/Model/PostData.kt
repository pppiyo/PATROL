package com.example.hw4_cs571.Model

data class PostData (
    val createdAt: String,
    val post : String
)