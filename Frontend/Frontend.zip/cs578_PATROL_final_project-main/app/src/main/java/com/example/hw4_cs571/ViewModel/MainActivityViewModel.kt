package com.example.hw4_cs571.ViewModel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.hw4_cs571.Model.CheckIn
import com.example.hw4_cs571.Model.Coordinate
import com.example.hw4_cs571.Model.SearchData
import com.example.hw4_cs571.Repositories.PatrolRepository
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.log2

class MainActivityViewModel : ViewModel() {
    private val patrolRepository = PatrolRepository()

    fun setFirstTimeInstall(checkIn: CheckIn) {
        viewModelScope.launch {
            patrolRepository.setFirstTimeInstall(checkIn)
        }
    }

    fun updateUserLocation(userId: String, coordinate: Coordinate) {
        viewModelScope.launch {
            patrolRepository.updateUserLocation(userId, coordinate)
        }
    }


}