# Patrol Application

In the architectural design of this android app, we focused on collecting geo-location information from various sources to plot current heatmap, history of reported cases, and symptoms report notification. The target users included developers who use the application API, and normal users who utilize app GUI to acquire information. 

## Screenshots

<img src="image.png" alt="drawing" width="200"/>
<img src="image-1.png" alt="drawing" width="200"/>
<img src="image-2.png" alt="drawing" width="200"/>

## Getting Started

### Project Structure

The project structure follow the Android Kotlin best practices. By applying the layer-style architecture and using the unidirectional data flow concept that made the application have two layers:
- The UI layer that displays application data on the screen.
    - View
    - ViewModel
- The data layer that contains the business logic of the application and exposes application data.
    - Data source
    - Repositories

<!-- end of the list -->
    .
    ├── ...
    ├── src                                             # Source code
    │   ├── main                                        # Application source code
    │   |   ├── java                                    
    │   |   |   ├── Data                                # Data source of the application contain the API service 
    │   |   |   ├── Model                               # Model of the passing data
    │   |   |   ├── Repositories                        # Centralizing changes and exposing the data to the rest of the application
    │   |   |   ├── ViewModel                           # ViewModel classes for hold data, expose it to the UI, and handle logic
    │   |   |   ├── Activity and Fragment (view)        # UI elements that render the data on the screen
    └── ...


### Installing and Executing the application
1. Extract the source code from the zip file
2. Open the project in Android Studio
<img src="image-3.png" alt="drawing" width="200"/>
3. Open the android emulator in this case we use android 13
<img src="image-4.png" alt="drawing" width="200"/>
4. Select the run button to install and run the application
<img src="image-5.png" alt="drawing" width="200"/>

## Authors

- Aditi Gajurel
- Felipe Gomez Castano
- Rishabh Nevatia
- Tanveesh Singh Chaudhery
- Vachirawit Tengchaisri
- Yueqin Li